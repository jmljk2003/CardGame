import ch.aplu.jcardgame.*;
import ch.aplu.jgamegrid.GGKeyListener;

import java.awt.event.KeyEvent;
import java.util.*;

import static ch.aplu.util.BaseTimer.delay;

public class HumanPlayer extends PlayerType implements GGKeyListener {
    Card selected;
    Card lastPlayed;
    private boolean isWaitingForPass = false;
    private volatile boolean passSelected = false;
    private volatile boolean validCardSelected = false;

    public HumanPlayer(Hand hand) {
        super(hand);
    }

    @Override
    public Card playCard(List<Card> cardsPlayed, boolean isNewRound) {
        // When it's the players turn, initialise values
        lastPlayed = GetLastPlayedCard(cardsPlayed, isNewRound);
        selected = null;
        isWaitingForPass = true;
        passSelected = false;
        validCardSelected = false;
        this.hand.setTouchEnabled(true);

        // Waiting for input
        while (!passSelected && !validCardSelected) {
            if(isValid(selected, lastPlayed) && !hasAceClubs(this.hand.getCardList())) {
                System.out.println("PLAYING " + selected);
            }
            else if(isValid(selected, lastPlayed) && hasAceClubs(this.hand.getCardList())) {
                System.out.println("PLAYING CLUBS-ACE");
            }
        }

        // If the pass flag is selected, return null
        if(passSelected){
            System.out.println("PASSING");
            selected = null;
        }

        // Turn off card and mouse interactions
        this.hand.setTouchEnabled(false);
        return selected;
    }



    // Enables listener for selecting a card by clicking
    public void enableCardSelection() {
        CardListener cardListener = new CardAdapter() {
            public void leftDoubleClicked(Card card) {

                selected = card;
                if(!isValid(selected, lastPlayed)){
                    System.out.println(selected + " IS NOT VALID");
                }
                else {
                    validCardSelected = true;
                }
            }
        };
        hand.addCardListener(cardListener);
        hand.setTouchEnabled(true);
    }

    @Override
    // Listens to key press
    public boolean keyPressed(KeyEvent keyEvent) {
        // When enter is pressed, skip
        if (isWaitingForPass && keyEvent.getKeyChar() == '\n') {
            isWaitingForPass = false;
            passSelected = true;
        }
        return false;
    }

    @Override
    public boolean keyReleased(KeyEvent keyEvent) {
        return false;
    }
}
