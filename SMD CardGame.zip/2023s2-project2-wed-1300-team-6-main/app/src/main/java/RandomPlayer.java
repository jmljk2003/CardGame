import ch.aplu.jcardgame.Card;
import ch.aplu.jcardgame.Hand;
import ch.aplu.jgamegrid.GameGrid;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static ch.aplu.util.BaseTimer.delay;

public class RandomPlayer extends PlayerType{
    static public final int seed = 30006;
    static final Random random = new Random(seed);

    public RandomPlayer(Hand hand) {
        super(hand);
    }

    @Override
    public Card playCard(List<Card> cardsPlayed, boolean isNewRound) {
        // Initialise last played card, and a list of valid cards the player can play
        Card lastPlayed = GetLastPlayedCard(cardsPlayed, isNewRound);
        List<Card>validCards = GetValidCards(this.hand.getCardList(), lastPlayed);
        Card selected;

        // Select random card from a list of valid cards
        selected = getRandomCard(validCards);

        return selected;
    }


    @Override
    public void enableCardSelection() {

    }

    // Return a random card from a list
    public Card getRandomCard(List<Card> validCardList) {
        Card selectedCard;

        // Return null if there are no playable cards, otherwise, get a random card from the list
        if(validCardList == null || validCardList.isEmpty()) {
            return null;
        }
        else {
            int x = random.nextInt(validCardList.size());
            selectedCard = validCardList.get(x);
            return selectedCard;
        }

    }
}
