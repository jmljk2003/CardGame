import ch.aplu.jcardgame.*;

import java.util.ArrayList;
import java.util.List;

public class PlayerFactory {
    private static PlayerFactory instance;

    private PlayerFactory() {}

    public static synchronized PlayerFactory getInstance() {
        if (instance == null) {
            instance = new PlayerFactory();
        }
        return instance;
    }

    public PlayerType createPlayer(String type, Hand hand) {
        if ("human".equalsIgnoreCase(type)) {
            return new HumanPlayer(hand);
        } else if ("random".equalsIgnoreCase(type)) {
            return new RandomPlayer(hand);
        } else if ("basic".equalsIgnoreCase(type)) {
            return new BasicPlayer(hand);
        } else if ("clever".equalsIgnoreCase(type)) {
            return new CleverPlayer(hand);
        }


        throw new IllegalArgumentException("Unknown player type");
    }
}
