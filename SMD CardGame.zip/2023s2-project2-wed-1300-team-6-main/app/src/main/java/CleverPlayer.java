import ch.aplu.jcardgame.Card;
import ch.aplu.jcardgame.Hand;

import java.util.ArrayList;
import java.util.List;

public class CleverPlayer extends PlayerType{
    public CleverPlayer(Hand hand) {
        super(hand);
    }

    @Override
    public Card playCard(List<Card> cardsPlayed, boolean isNewRound) {
        // Initialise last played card, and a list of valid cards the player can play
        Card selected = null;
        Card lastPlayed = GetLastPlayedCard(cardsPlayed, isNewRound);
        List<Card>validCards = GetValidCards(this.hand.getCardList(), lastPlayed);

        // If there are no playable cards, return null
        if (validCards.isEmpty() || cardsPlayed.isEmpty()) {
            return null;  // No valid cards to play, must pass
        }

        // Initialise values for the current strongest card in th game
        int currentStrongestRank = getCurrentStrongestRank(cardsPlayed);
        int strongestAmountPlayed = getRankAmount(cardsPlayed, currentStrongestRank);
        int strongestAmountInHand = getRankAmount(this.hand.getCardList(), currentStrongestRank);
        int secondStrongestRank = getSecondStrongestRank(cardsPlayed, currentStrongestRank);

        // If you don't hold the strongest rank card in your hand, end the round as soon as possible by playing the highest valid card
        if(strongestAmountInHand == 0){
            selected = getHighestCard(validCards);
        }
        // If you have more than 1 of the strongest rank card in your hand, it's an automatic win, play the lowest card to maximise score
        else if(strongestAmountInHand > 1) {
            selected = getLowestCard(validCards);
        }
        // If you have only 1 of the strongest rank card in your hand, but not all of them have been played yet
        else if(strongestAmountInHand == 1 && strongestAmountPlayed < 3) {
            // Play the lowest card
            selected = getLowestCard(validCards);
            // If the only card you can play is the strongest card in this case, skip
            if(lastPlayed != null && selected.getRankId() == currentStrongestRank) {
                selected = null;
            }
            // If you are starting the round in this condition, play the highest card
            else if(isNewRound) {
                selected = getHighestCard(validCards);
            }
        }
        // If you have only 1 of the strongest rank card in your hand, but all 3 have been played, its an automatic win
        else if(strongestAmountInHand == 1 && strongestAmountPlayed == 3) {
            selected = getLowestCard(validCards);
            // If the last played card is the second strongest, play your strongest
            if(lastPlayed != null && lastPlayed.getRankId() == secondStrongestRank) {
                selected = getHighestCard(validCards);
            }
        }

        return selected;
    }

    // Return the strongest playable card rank in the game
    private int getCurrentStrongestRank(List<Card> cardsPlayed) {
        int currentStrongest = 1; // set to KING by default
        int strongestAmountPlayed = 0;
        boolean Strongestfound = false;

        while(!Strongestfound){
            for(Card cards : cardsPlayed) {
                Strongestfound = true;
                if(cards.getRankId() == currentStrongest) {
                    strongestAmountPlayed += 1;

                }
                if(strongestAmountPlayed == 4) {
                    currentStrongest += 1;
                    Strongestfound = false;
                    break;
                }
            }
            strongestAmountPlayed = 0;
        }

        return currentStrongest;
    }

    // Return the second-strongest playable card rank in the game
    private int getSecondStrongestRank(List<Card> cardsPlayed, int strongestRank) {
        int currSecondStrongest = strongestRank + 1;
        int amountSecondStrongestPlayed = 0;
        boolean foundTarget = false;

        while(!foundTarget){
            for(Card cards : cardsPlayed) {
                foundTarget = true;
                if (cards.getRankId() == currSecondStrongest) {
                    amountSecondStrongestPlayed += 1;
                }
                if (amountSecondStrongestPlayed == 4) {
                    currSecondStrongest += 1;
                    foundTarget = false;
                    break;
                }
                amountSecondStrongestPlayed = 0;
            }
        }

        return currSecondStrongest;
    }

    // Return the number of cards of a certain rank from a list of cards
    private int getRankAmount(List<Card> cardsPlayed, int rank) {
        int amountPlayed = 0;
        for(Card cards : cardsPlayed) {
            if(cards.getRankId() == rank) {
                amountPlayed += 1;
            }
        }
        return amountPlayed;
    }

    @Override
    public void enableCardSelection() {

    }


}
