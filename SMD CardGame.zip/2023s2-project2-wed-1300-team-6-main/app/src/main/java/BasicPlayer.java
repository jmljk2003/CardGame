import ch.aplu.jcardgame.Card;
import ch.aplu.jcardgame.Hand;

import java.util.ArrayList;
import java.util.List;

import static ch.aplu.util.BaseTimer.delay;

public class BasicPlayer extends PlayerType{
    public BasicPlayer(Hand hand) {
        super(hand);
    }

    @Override
    public Card playCard(List<Card> cardsPlayed, boolean isNewRound) {
        // Initialise last played card, and a list of valid cards the player can play
        Card lastPlayed = GetLastPlayedCard(cardsPlayed, isNewRound);
        List<Card>validCards = GetValidCards(this.hand.getCardList(), lastPlayed);
        Card selected;

        // Select the card with the lowest rank among the valid cards
        selected = getLowestCard(validCards);

        return selected;
    }

    @Override
    public void enableCardSelection() {

    }


}
