// CountingUpGame.java

import ch.aplu.jcardgame.*;
import ch.aplu.jgamegrid.*;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

@SuppressWarnings("serial")
public class CountingUpGame extends CardGame {

    public enum Suit {
        SPADES ("S"), HEARTS ("H"), DIAMONDS ("D"), CLUBS ("C");
        private String suitShortHand = "";
        Suit(String shortHand) {
            this.suitShortHand = shortHand;
        }

        public String getSuitShortHand() {
            return suitShortHand;
        }
    }

    public enum Rank {
        // Reverse order of rank importance (see rankGreater() below)
        ACE (1, 10), KING (13, 10), QUEEN (12, 10),
        JACK (11, 10), TEN (10, 10), NINE (9, 9),
        EIGHT (8, 8), SEVEN (7, 7), SIX (6, 6),
        FIVE (5, 5), FOUR (4, 4), THREE (3, 3),
        TWO (2, 2);

        private int rankCardValue = 1;
        private int scoreCardValue = 1;
        Rank(int rankCardValue, int scoreCardValue) {
            this.rankCardValue = rankCardValue;
            this.scoreCardValue = scoreCardValue;
        }

        public int getRankCardValue() {
            return rankCardValue;
        }

        public int getScoreCardValue() { return scoreCardValue; }

        public String getRankCardLog() {
            return String.format("%d", rankCardValue);
        }
    }

    static public final int seed = 30008;
    static final Random random = new Random(seed);
    private Properties properties;
    private StringBuilder logResult = new StringBuilder();
    private List<List<String>> playerAutoMovements = new ArrayList<>();

    private final String version = "1.0";
    public final int nbPlayers = 4;
    public final int nbStartCards = 13;
    public final int nbRounds = 3;
    private final int handWidth = 400;
    private final int trickWidth = 40;
    private final Deck deck = new Deck(Suit.values(), Rank.values(), "cover");
    private final Location[] handLocations = {
            new Location(350, 625),
            new Location(75, 350),
            new Location(350, 75),
            new Location(625, 350)
    };
    private final Location[] scoreLocations = {
            new Location(575, 675),
            new Location(25, 575),
            new Location(575, 25),
            // new Location(650, 575)
            new Location(575, 575)
    };
    private Actor[] scoreActors = {null, null, null, null};
    private final Location trickLocation = new Location(350, 350);
    private final Location textLocation = new Location(350, 450);
    private int thinkingTime = 2000;
    private int delayTime = 600;
    private PlayerType[] players;
    private Location hideLocation = new Location(-500, -500);

    public void setStatus(String string) {
        setStatusText(string);
    }

    private int[] scores = new int[nbPlayers];
    private int[] autoIndexHands = new int [nbPlayers];
    private boolean isAuto = false;

    Font bigFont = new Font("Arial", Font.BOLD, 36);

    private void initScore() {
        for (int i = 0; i < nbPlayers; i++) {
            // scores[i] = 0;
            String text = "[" + String.valueOf(scores[i]) + "]";
            scoreActors[i] = new TextActor(text, Color.WHITE, bgColor, bigFont);
            addActor(scoreActors[i], scoreLocations[i]);
        }
    }

    private void calculateScoreEndOfRound(int player, List<Card> cardsPlayed) {
        int totalScorePlayed = 0;
        for (Card card: cardsPlayed) {
            Rank rank = (Rank) card.getRank();
            totalScorePlayed += rank.getScoreCardValue();
        }
        scores[player] += totalScorePlayed;
    }

    private void calculateNegativeScoreEndOfGame(int player, List<Card> cardsInHand) {
        int totalScorePlayed = 0;
        for (Card card: cardsInHand) {
            Rank rank = (Rank) card.getRank();
            totalScorePlayed -= rank.getScoreCardValue();
        }
        scores[player] += totalScorePlayed;
    }

    private void updateScore(int player) {
        removeActor(scoreActors[player]);
        int displayScore = scores[player] >= 0 ? scores[player] : 0;
        String text = "P" + player + "[" + String.valueOf(displayScore) + "]";
        scoreActors[player] = new TextActor(text, Color.WHITE, bgColor, bigFont);
        addActor(scoreActors[player], scoreLocations[player]);
    }

    private void initScores() {
        for (int i = 0; i < nbPlayers; i++) {
            scores[i] = 0;
        }
    }

    private Card selected;
    List<Card>cardsPlayed = new ArrayList<>();
    List<Card>totalCardsPlayed = new ArrayList<>();
    private boolean isNewRound = true;
    PlayerFactory playerFactory = PlayerFactory.getInstance();

    // Initialises playertypes in an array in turn order
    private void setupPlayers() {
        String[] playerSetup = new String[nbPlayers];
        players = new PlayerType[nbPlayers];
        String player0 = properties.getProperty("players.0");
        String player1 = properties.getProperty("players.1");
        String player2 = properties.getProperty("players.2");
        String player3 = properties.getProperty("players.3");

        playerSetup[0] = player0;
        playerSetup[1] = player1;
        playerSetup[2] = player2;
        playerSetup[3] = player3;
        System.out.println("GAME SEED: " + seed);

        for (int i = 0; i < nbPlayers; i++) {
            if (playerSetup[i].equals("human")) {
                System.out.printf("Player%d created of type Human\n", i);
                players[i] = playerFactory.createPlayer("human", new Hand(deck));
            }
            if (playerSetup[i].equals("random")) {
                System.out.printf("Player%d created of type Random\n", i);
                players[i] = playerFactory.createPlayer("random", new Hand(deck));
            }
            if (playerSetup[i].equals("basic")) {
                System.out.printf("Player%d created of type Basic\n", i);
                players[i] = playerFactory.createPlayer("basic", new Hand(deck));
            }
            if (playerSetup[i].equals("clever")) {
                System.out.printf("Player%d created of type Clever\n", i);
                players[i] = playerFactory.createPlayer("clever", new Hand(deck));
            }
        }

    }

    // Set up initial game
    private void initGame() {
        // Set up Properties and Initialise Hands
        setupPlayers();

        // Deal Cards to Players
        dealingOut(players, nbPlayers, nbStartCards);

        // Sort Hands for each Player
        for (int i = 0; i < nbPlayers; i++) {
            players[i].hand.sort(Hand.SortType.SUITPRIORITY, false);
        }

        // Distribute listener to all Humanplayer type players
        for(int j = 0; j < nbPlayers; j++) {
            if(players[j] instanceof HumanPlayer humanPlayer){
                players[j].enableCardSelection();
                players[j].hand.setTouchEnabled(false);

                // Add key listener
                addKeyListener(humanPlayer);
            }
        }

        // graphics
        RowLayout[] layouts = new RowLayout[nbPlayers];
        for (int i = 0; i < nbPlayers; i++) {
            layouts[i] = new RowLayout(handLocations[i], handWidth);
            layouts[i].setRotationAngle(90 * i);
            //layouts[i].setStepDelay(10);
            players[i].hand.setView(this, layouts[i]);
            players[i].hand.setTargetArea(new TargetArea(trickLocation));
            players[i].hand.draw();
        }
    }


    // return random Enum value
    public static <T extends Enum<?>> T randomEnum(Class<T> clazz) {
        int x = random.nextInt(clazz.getEnumConstants().length);
        return clazz.getEnumConstants()[x];
    }

    // return random Card from ArrayList
    public static Card randomCard(ArrayList<Card> list) {
        int x = random.nextInt(list.size());
        return list.get(x);
    }

    private Rank getRankFromString(String cardName) {
        String rankString = cardName.substring(0, cardName.length() - 1);
        Integer rankValue = Integer.parseInt(rankString);

        for (Rank rank : Rank.values()) {
            if (rank.getRankCardValue() == rankValue) {
                return rank;
            }
        }

        return Rank.ACE;
    }

    private Suit getSuitFromString(String cardName) {
        String suitString = cardName.substring(cardName.length() - 1);

        for (Suit suit : Suit.values()) {
            if (suit.getSuitShortHand().equals(suitString)) {
                return suit;
            }
        }
        return Suit.CLUBS;
    }

    private Card getCardFromList(List<Card> cards, String cardName) {
        Rank cardRank = getRankFromString(cardName);
        Suit cardSuit = getSuitFromString(cardName);
        for (Card card: cards) {
            if (card.getSuit() == cardSuit
                    && card.getRank() == cardRank) {
                return card;
            }
        }

        return null;
    }

    // Deals out cards to players
    private void dealingOut(PlayerType[] players, int nbPlayers, int nbCardsPerPlayer) {
        Hand pack = deck.toHand(false);

        for (int i = 0; i < nbPlayers; i++) {
            String initialCardsKey = "players." + i + ".initialcards";
            String initialCardsValue = properties.getProperty(initialCardsKey);
            if (initialCardsValue == null) {
                continue;
            }
            String[] initialCards = initialCardsValue.split(",");
            for (String initialCard: initialCards) {
                if (initialCard.length() <= 1) {
                    continue;
                }
                Card card = getCardFromList(pack.getCardList(), initialCard);
                if (card != null) {
                    card.removeFromHand(false);
                    players[i].hand.insert(card, false);
                }
            }
        }

        for (int i = 0; i < nbPlayers; i++) {
            int cardsToDealt = nbCardsPerPlayer - players[i].hand.getNumberOfCards();
            for (int j = 0; j < cardsToDealt; j++) {
                if (pack.isEmpty()) return;
                Card dealt = randomCard(pack.getCardList());
                dealt.removeFromHand(false);
                players[i].hand.insert(dealt, false);
            }
        }
    }

    // Get the player index with the ace of clubs
    private int playerIndexWithAceClub() {
        for (int i = 0; i < nbPlayers; i++) {
            Hand hand = players[i].hand;
            List<Card> cards = hand.getCardsWithRank(Rank.ACE);
            if (cards.size() == 0) {
                continue;
            }
            for (Card card: cards) {
                if (card.getSuit() == Suit.CLUBS) {
                    return i;
                }
            }
        }

        return 0;
    }

    private void addCardPlayedToLog(int player, Card selectedCard) {
        if (selectedCard == null) {
            logResult.append("P" + player + "-SKIP,");
        } else {
            Rank cardRank = (Rank) selectedCard.getRank();
            Suit cardSuit = (Suit) selectedCard.getSuit();
            logResult.append("P" + player + "-" + cardRank.getRankCardLog() + cardSuit.getSuitShortHand() + ",");
        }
    }

    private void addRoundInfoToLog(int roundNumber) {
        logResult.append("Round" + roundNumber + ":");
    }

    private void addEndOfRoundToLog() {
        logResult.append("Score:");
        for (int i = 0; i < scores.length; i++) {
            logResult.append(scores[i] + ",");
        }
        logResult.append("\n");
    }

    private void addEndOfGameToLog(List<Integer> winners) {
        logResult.append("EndGame:");
        for (int i = 0; i < scores.length; i++) {
            logResult.append(scores[i] + ",");
        }
        logResult.append("\n");
        logResult.append("Winners:" + String.join(", ", winners.stream().map(String::valueOf).collect(Collectors.toList())));
    }

    // Main game loop
    private void playGame() {
        // End trump suit
        Hand playingArea = null;
        int winner = 0;
        int roundNumber = 1;
        for (int i = 0; i < nbPlayers; i++) updateScore(i);
        boolean isContinue = true;
        boolean acePlayed = false;
        int skipCount = 0;
        playingArea = new Hand(deck);
        addRoundInfoToLog(roundNumber);
        Card lastPlayed = null;
        int nextPlayer = playerIndexWithAceClub();

        while(isContinue) {
            selected = null;
            boolean finishedAuto = false;

            // Predetermined play
            if (isAuto) {
                int nextPlayerAutoIndex = autoIndexHands[nextPlayer];
                List<String> nextPlayerMovement = playerAutoMovements.get(nextPlayer);
                String nextMovement = "";

                if (nextPlayerMovement.size() > nextPlayerAutoIndex) {
                    isNewRound = false;
                    nextMovement = nextPlayerMovement.get(nextPlayerAutoIndex);
                    nextPlayerAutoIndex++;

                    autoIndexHands[nextPlayer] = nextPlayerAutoIndex;
                    Hand nextHand = players[nextPlayer].hand;

                    if (nextMovement.equals("SKIP")) {
                        setStatusText("Player " + nextPlayer + " skipping...");
                        delay(thinkingTime);
                        selected = null;
                    } else {
                        setStatusText("Player " + nextPlayer + " thinking...");
                        delay(thinkingTime);
                        selected = getCardFromList(nextHand.getCardList(), nextMovement);
                    }
                } else {
                    finishedAuto = true;
                }
            }

            // Non-predetermined play
            if (!isAuto || finishedAuto){
                if (players[nextPlayer] instanceof HumanPlayer) {
                    setStatus("Player " + nextPlayer + " double-click on card to follow or press Enter to pass");
                }
                else {
                    setStatusText("Player " + nextPlayer + " thinking...");
                }

                // Player plays card
                selected = players[nextPlayer].playCard(totalCardsPlayed, isNewRound);

                if(roundNumber == 1 && nextPlayer == playerIndexWithAceClub() && !acePlayed){
                    selected = players[nextPlayer].playSmall();
                    acePlayed = true;
                }
                isNewRound = false;
                if (selected == null) {
                    setStatusText("Player " + nextPlayer + " skipping...");
                    delay(thinkingTime);
                }
            }

            // Follow with selected card
            playingArea.setView(this, new RowLayout(trickLocation, (playingArea.getNumberOfCards() + 2) * trickWidth));
            playingArea.draw();
            addCardPlayedToLog(nextPlayer, selected);
            if (selected != null) {
                skipCount = 0;
                cardsPlayed.add(selected);
                totalCardsPlayed.add(selected);
                selected.setVerso(false);  // In case it is upside down
                // Check: Following card must follow suit if possible

                // End Check
                selected.transfer(playingArea, true); // transfer to trick (includes graphic effect)
                delay(delayTime);
                // End Follow
            } else {
                skipCount++;
            }

            if (skipCount == nbPlayers - 1) {
                playingArea.setView(this, new RowLayout(hideLocation, 0));
                playingArea.draw();
                winner = (nextPlayer + 1) % nbPlayers;
                skipCount = 0;
                calculateScoreEndOfRound(winner, cardsPlayed);
                updateScore(winner);
                addEndOfRoundToLog();
                roundNumber++;
                addRoundInfoToLog(roundNumber);
                cardsPlayed = new ArrayList<>();
                isNewRound = true;
                delay(delayTime);
                playingArea = new Hand(deck);
            }

            isContinue = players[0].hand.getNumberOfCards() > 0 && players[1].hand.getNumberOfCards() > 0 &&
                    players[2].hand.getNumberOfCards() > 0 && players[3].hand.getNumberOfCards() > 0;
            if (!isContinue) {
                winner = nextPlayer;
                calculateScoreEndOfRound(winner, cardsPlayed);
                addEndOfRoundToLog();
            } else {
                nextPlayer = (nextPlayer + 1) % nbPlayers;
            }
            delay(delayTime);
        }

        for (int i = 0; i < nbPlayers; i++) {
            calculateNegativeScoreEndOfGame(i, players[i].hand.getCardList());
            updateScore(i);
        }
    }

    private void setupPlayerAutoMovements() {
        String player0AutoMovement = properties.getProperty("players.0.cardsPlayed");
        String player1AutoMovement = properties.getProperty("players.1.cardsPlayed");
        String player2AutoMovement = properties.getProperty("players.2.cardsPlayed");
        String player3AutoMovement = properties.getProperty("players.3.cardsPlayed");

        String[] playerMovements = new String[] {"", "", "", ""};
        if (player0AutoMovement != null) {
            playerMovements[0] = player0AutoMovement;
        }

        if (player1AutoMovement != null) {
            playerMovements[1] = player1AutoMovement;
        }

        if (player2AutoMovement != null) {
            playerMovements[2] = player2AutoMovement;
        }

        if (player3AutoMovement != null) {
            playerMovements[3] = player3AutoMovement;
        }

        for (int i = 0; i < playerMovements.length; i++) {
            String movementString = playerMovements[i];
            List<String> movements = Arrays.asList(movementString.split(","));
            playerAutoMovements.add(movements);
        }
    }

    public String runApp() {
        setTitle("CountingUpGame (V" + version + ") Constructed for UofM SWEN30006 with JGameGrid (www.aplu.ch)");
        setStatusText("Initializing...");
        initScores();
        initScore();
        setupPlayerAutoMovements();
        initGame();
        playGame();

        for (int i = 0; i < nbPlayers; i++) updateScore(i);
        int maxScore = 0;
        for (int i = 0; i < nbPlayers; i++) if (scores[i] > maxScore) maxScore = scores[i];
        List<Integer> winners = new ArrayList<Integer>();
        for (int i = 0; i < nbPlayers; i++) if (scores[i] == maxScore) winners.add(i);
        String winText;
        if (winners.size() == 1) {
            winText = "Game over. Winner is player: " +
                    winners.iterator().next();
        } else {
            winText = "Game Over. Drawn winners are players: " +
                    String.join(", ", winners.stream().map(String::valueOf).collect(Collectors.toList()));
        }
        addActor(new Actor("sprites/gameover.gif"), textLocation);
        setStatusText(winText);
        refresh();
        addEndOfGameToLog(winners);

        return logResult.toString();
    }

    public CountingUpGame(Properties properties) {
        super(700, 700, 30);
        this.properties = properties;
        isAuto = Boolean.parseBoolean(properties.getProperty("isAuto"));
        thinkingTime = Integer.parseInt(properties.getProperty("thinkingTime", "200"));
        delayTime = Integer.parseInt(properties.getProperty("delayTime", "100"));
    }
}
