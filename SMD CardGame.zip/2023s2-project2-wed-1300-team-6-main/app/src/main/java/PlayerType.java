import ch.aplu.jcardgame.*;

import java.util.ArrayList;
import java.util.List;

public abstract class PlayerType {
    protected Hand hand;

    // Constructor for player types
    public PlayerType(Hand hand) {
        this.hand = hand;
    }

    // Return card based on given parameters
    public abstract Card playCard(List<Card> cardsPlayed, boolean isNewRound);

    // Enable listener for card selection (Human Player)
    public abstract void enableCardSelection();

    // Checks if a card is valid based on the last played card
    public static boolean isValid(Card checkCard, Card lastPlayed){
        if(checkCard != null){
            if(lastPlayed == null || (checkCard.getRankId() < lastPlayed.getRankId() && checkCard.getSuit() ==
                    lastPlayed.getSuit() && checkCard.getRankId() != 0 ) || (lastPlayed.getRankId() == 0 && checkCard.getSuit() == lastPlayed.getSuit()) ||
                    checkCard.getRankId() == lastPlayed.getRankId()){
                return true;
            }
        }

        return false;
    }

    // Automatically play the ace of clubs
    public Card playSmall(){
        Card selected = null;
        ArrayList<Card> listCard = this.hand.getCardList();
        for(Card card : listCard){
            if(card.getRank() == CountingUpGame.Rank.ACE && card.getSuit() == CountingUpGame.Suit.CLUBS){
                selected = card;
            }
        }
        return selected;
    }

    // Returns true or false depending if a hand has ace of clubs or not
    public static boolean hasAceClubs(ArrayList<Card> handList){
        for(Card card : handList){
            if(card.getRank() == CountingUpGame.Rank.ACE && card.getSuit() == CountingUpGame.Suit.CLUBS){
                return  true;
            }
        }
        return false;
    }

    // Returns the most recent card on the list
    public static Card GetLastPlayedCard(List<Card> cardsPlayed, boolean isNewRound){
        if(isNewRound) {
            return null;
        }
        else{
            return cardsPlayed.get(cardsPlayed.size() - 1);
        }

    }

    // Returns all valid cards based on the last played card
    public static List<Card> GetValidCards(ArrayList<Card> handList, Card lastPlayed){
        List<Card>validCards = new ArrayList<>();
        for (Card selected : handList){
            if(isValid(selected, lastPlayed)){
                validCards.add(selected);
            }
        }
        return validCards;
    }

    // Returns the card with the lowest rank from a list of cards
    public static Card getLowestCard(List<Card> cardList){
        Card minCard = null;

        if(cardList == null){
            return null;
        }

        for (Card card : cardList){
            if(minCard == null) {
                minCard = card;
            }
            else {
                if(card.getRankId() > minCard.getRankId()) {
                    minCard = card;
                }
            }
        }

        return minCard;
    }

    // Returns the card with the highest rank from a list of cards
    public static Card getHighestCard(List<Card> cardList){
        Card maxCard = null;

        if(cardList == null){
            return null;
        }

        for (Card card : cardList){
            if(maxCard == null) {
                maxCard = card;
            }
            else {
                if(card.getRankId() < maxCard.getRankId()) {
                    maxCard = card;
                }
            }
        }

        return maxCard;
    }
}
